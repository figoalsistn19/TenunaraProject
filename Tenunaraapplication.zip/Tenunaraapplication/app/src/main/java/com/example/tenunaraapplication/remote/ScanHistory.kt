package com.example.tenunaraapplication.remote

data class ScanHistory(
    var Foto_scan: String ?= null,
    var Id_tenun: String ?= null,
    var Id_user: String ?= null,
    var Nama_user: String ?= null,
)
